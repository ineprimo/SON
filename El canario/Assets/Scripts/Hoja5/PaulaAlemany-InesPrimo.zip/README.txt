Hay dos archivos para separar el gestor de mezclas y el dispersor como tal.

El soundManager gestiona las mezclas y el intermitentSound controla el dispersor.